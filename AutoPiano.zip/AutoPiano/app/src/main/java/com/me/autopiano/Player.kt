package com.me.autopiano

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.SystemClock
import kotlinx.coroutines.*
import kotlin.math.abs
import kotlin.random.Random

/**
 * Plays notes in short "segments". Each segment = one multi-finger gesture (all notes starting in the
 * next ~700ms). Timing is wall-clock anchored, so tempo changes / pause / resume work between segments.
 */
class Player(private val svc: AccessibilityService, private val scope: CoroutineScope) {
    var notes: List<Note> = emptyList(); private set
    var speed = 1.0
        set(v) { field = v.coerceIn(0.25, 2.0); if (playing) reanchor() }
    var style = Style.CLASSICAL
    var pedal = false
    var keys: KeyMap? = null
    var playing = false; private set
    var onState: (() -> Unit)? = null

    private var idx = 0
    private var pos = 0.0           // song ms (at original tempo)
    private var anchorReal = 0L
    private var anchorSong = 0.0
    private var spd = 1.0
    private var human = 0.0
    private var job: Job? = null

    private fun curSpeed() = speed * (1 + human)
    private fun songPos() = anchorSong + (SystemClock.uptimeMillis() - anchorReal) * spd
    private fun reanchor() { anchorSong = songPos(); anchorReal = SystemClock.uptimeMillis(); spd = curSpeed() }

    fun load(n: List<Note>) { stop(); notes = n }

    fun stop() {
        playing = false; job?.cancel(); idx = 0; pos = 0.0; onState?.invoke()
    }

    fun pause() {
        if (!playing) return
        pos = songPos(); playing = false; job?.cancel(); onState?.invoke()
    }

    fun restart() { stop(); play() }

    fun play() {
        if (playing || notes.isEmpty() || keys == null) return
        if (idx >= notes.size) { idx = 0; pos = 0.0 }
        playing = true
        anchorSong = pos; anchorReal = SystemClock.uptimeMillis(); spd = curSpeed()
        onState?.invoke()
        job = scope.launch {
            loop()
            if (playing) { playing = false; idx = 0; pos = 0.0; onState?.invoke() }
        }
    }

    private suspend fun loop() {
        val rnd = Random
        while (playing && idx < notes.size) {
            val k = keys ?: return
            val first = notes[idx]
            val wait = (first.startMs - songPos()) / spd
            if (wait > 15) { delay(minOf(wait.toLong(), 100L)); continue }

            // slow random tempo drift (humanizer)
            if (style.drift > 0) human = (human + (rnd.nextDouble() - 0.5) * style.drift * 0.5).coerceIn(-style.drift, style.drift)
            else human = 0.0
            reanchor()

            val usePedal = pedal && k.c.hasPedal
            val maxS = (GestureDescription.getMaxStrokeCount() - if (usePedal) 1 else 0).coerceAtLeast(1)
            val windowSong = 700.0 * spd
            val segStart = first.startMs
            val picks = ArrayList<Note>()
            var j = idx
            while (j < notes.size && picks.size < maxS && notes[j].startMs < segStart + windowSong) { picks.add(notes[j]); j++ }
            val segEndSong = if (j < notes.size && notes[j].startMs < segStart + windowSong) notes[j].startMs else segStart + windowSong
            idx = j
            val segLen = ((segEndSong - segStart) / spd).coerceAtLeast(60.0)

            val b = GestureDescription.Builder()
            var any = false
            var chordStart = -1.0; var rank = 0
            for ((i, n) in picks.withIndex()) {
                if (rnd.nextDouble() < style.miss) continue
                var pitch = n.pitch
                if (rnd.nextDouble() < style.wrong) pitch += listOf(-2, -1, 1, 2).random()
                val (x, y) = k.point(pitch)
                if (abs(n.startMs - chordStart) < 8) rank++ else { chordStart = n.startMs; rank = 0 }
                val shift = if (style.swing > 0 && n.beat in 0.4..0.6) style.swing * 500 else 0.0
                val jit = if (style.jitter > 0) rnd.nextInt(-style.jitter, style.jitter + 1) else 0
                val off = ((n.startMs + shift - segStart) / spd + jit + minOf(rank, 4) * style.roll / 3.0).coerceIn(0.0, segLen)
                val holdF = style.hold * (if (style.jitter > 0) 0.9 + rnd.nextDouble() * 0.2 else 1.0)
                var dur = minOf(n.durMs / spd * holdF, segLen - off)
                // don't overlap the same key re-struck later in this segment
                for (m in i + 1 until picks.size) if (picks[m].pitch == n.pitch) {
                    dur = minOf(dur, (picks[m].startMs - n.startMs) / spd - 25); break
                }
                dur = dur.coerceAtLeast(30.0)
                val path = Path().apply { moveTo(x, y) }
                b.addStroke(GestureDescription.StrokeDescription(path, off.toLong(), dur.toLong()))
                any = true
            }
            if (!any) continue
            if (usePedal) {
                val path = Path().apply { moveTo(k.c.px, k.c.py) }
                b.addStroke(GestureDescription.StrokeDescription(path, 0, (segLen - 40).coerceAtLeast(30.0).toLong()))
            }
            suspendCancellableCoroutine<Unit> { c ->
                val ok = svc.dispatchGesture(b.build(), object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(g: GestureDescription?) { if (c.isActive) c.resumeWith(Result.success(Unit)) }
                    override fun onCancelled(g: GestureDescription?) { if (c.isActive) c.resumeWith(Result.success(Unit)) }
                }, null)
                if (!ok && c.isActive) c.resumeWith(Result.success(Unit))
            }
        }
    }
}
