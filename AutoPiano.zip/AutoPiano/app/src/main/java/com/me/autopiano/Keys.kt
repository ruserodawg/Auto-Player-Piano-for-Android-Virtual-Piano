package com.me.autopiano

/** x0,wy = lowest white key center. x1 = highest white key x. by = black key y. px,py = pedal (px<0 = none). */
data class Calib(val x0: Float, val wy: Float, val x1: Float, val by: Float, val px: Float, val py: Float) {
    val hasPedal get() = px >= 0f
}

enum class Style(
    val label: String, val jitter: Int, val hold: Float, val swing: Double,
    val wrong: Double, val miss: Double, val roll: Int, val drift: Double
) {
    OFF("Robot", 0, 1f, 0.0, 0.0, 0.0, 0, 0.0),
    CLASSICAL("Classical", 8, 1f, 0.0, 0.0, 0.0, 12, 0.015),
    JAZZ("Jazzy", 15, 0.8f, 0.14, 0.0, 0.0, 20, 0.02),
    HUMAN("Full Human", 28, 0.9f, 0.05, 0.03, 0.015, 30, 0.04)
}

class KeyMap(is88: Boolean, val c: Calib) {
    private val low = if (is88) 21 else 36   // A0 / C2
    private val high = if (is88) 108 else 96 // C8 / C7
    private fun black(n: Int) = when (n % 12) { 1, 3, 6, 8, 10 -> true; else -> false }
    private val wi = IntArray(high + 2)
    private val whites: Int
    init {
        var w = 0
        for (n in low..high) { wi[n] = w; if (!black(n)) w++ }
        whites = w
    }
    private val step = (c.x1 - c.x0) / (whites - 1)

    fun fit(p: Int): Int { var n = p; while (n < low) n += 12; while (n > high) n -= 12; return n }

    /** returns x,y on screen */
    fun point(pitch: Int): Pair<Float, Float> {
        val n = fit(pitch)
        return if (black(n)) Pair(c.x0 + (wi[n] - 0.5f) * step, c.by)
        else Pair(c.x0 + wi[n] * step, c.wy)
    }
}
