package com.me.autopiano

/** startMs/durMs are at the file's original tempo. beat = position inside the beat (0..1), used for swing. */
class Note(val startMs: Double, val durMs: Double, val pitch: Int, val beat: Double)

object Midi {
    fun parse(d: ByteArray): List<Note> {
        var p = 0
        fun u8(): Int = d[p++].toInt() and 0xFF
        fun u16(): Int { val a = u8(); return (a shl 8) or u8() }
        fun u32(): Int { val a = u16(); return (a shl 16) or u16() }
        fun vlq(): Int { var v = 0; while (true) { val b = u8(); v = (v shl 7) or (b and 0x7F); if (b and 0x80 == 0) return v } }

        require(u32() == 0x4D546864) { "Not a MIDI file" }
        u32(); u16()
        val ntrks = u16()
        val div = u16()
        val ppq = if (div and 0x8000 != 0) 480 else div

        val tempos = ArrayList<LongArray>()   // tick, microsec per quarter
        val raw = ArrayList<LongArray>()      // startTick, endTick, pitch

        for (t in 0 until ntrks) {
            if (p + 8 > d.size) break
            val id = u32(); val len = u32()
            val end = p + len
            if (id != 0x4D54726B) { p = end; continue }
            var tick = 0L; var status = 0
            val open = HashMap<Int, Long>()
            while (p < end) {
                tick += vlq()
                val b = u8()
                if (b and 0x80 != 0) status = b else p--
                when {
                    status == 0xFF -> {
                        val type = u8(); val l = vlq()
                        if (type == 0x51 && l == 3) {
                            val a = u8(); val bb = u8(); val c = u8()
                            tempos.add(longArrayOf(tick, ((a shl 16) or (bb shl 8) or c).toLong()))
                        } else p += l
                        if (type == 0x2F) p = end
                    }
                    status == 0xF0 || status == 0xF7 -> p += vlq()
                    else -> {
                        val type = status and 0xF0; val ch = status and 0x0F
                        if (type == 0xC0 || type == 0xD0) u8() else {
                            val a = u8(); val v = u8()
                            val key = ch * 128 + a
                            if (ch != 9) { // skip drums
                                if (type == 0x90 && v > 0) {
                                    open[key]?.let { raw.add(longArrayOf(it, tick, a.toLong())) }
                                    open[key] = tick
                                } else if (type == 0x80 || type == 0x90) {
                                    open.remove(key)?.let { raw.add(longArrayOf(it, tick, a.toLong())) }
                                }
                            }
                        }
                    }
                }
            }
            p = end
            for ((k, s) in open) raw.add(longArrayOf(s, tick, (k % 128).toLong()))
        }

        tempos.sortBy { it[0] }
        if (tempos.isEmpty() || tempos[0][0] > 0) tempos.add(0, longArrayOf(0, 500000))
        val ms = DoubleArray(tempos.size)
        for (i in 1 until tempos.size)
            ms[i] = ms[i - 1] + (tempos[i][0] - tempos[i - 1][0]) * tempos[i - 1][1] / 1000.0 / ppq
        fun toMs(t: Long): Double {
            var i = tempos.size - 1
            while (i > 0 && tempos[i][0] > t) i--
            return ms[i] + (t - tempos[i][0]) * tempos[i][1] / 1000.0 / ppq
        }

        return raw.map {
            val s = toMs(it[0])
            Note(s, maxOf(toMs(it[1]) - s, 30.0), it[2].toInt(), (it[0] % ppq).toDouble() / ppq)
        }.sortedWith(compareBy({ it.startMs }, { it.pitch }))
    }
}
