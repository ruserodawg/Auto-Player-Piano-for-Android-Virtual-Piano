package com.me.autopiano

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.SharedPreferences
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.text.TextUtils
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.view.ContextThemeWrapper
import android.widget.*
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.*
import kotlin.math.roundToInt

class PianoService : AccessibilityService() {
    companion object { var instance: PianoService? = null }

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var ui: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var player: Player
    private var panel: View? = null
    private var calView: View? = null
    private var is88 = false

    private lateinit var playBtn: Button
    private lateinit var songLbl: TextView
    private lateinit var speedLbl: TextView
    private lateinit var styleBtn: Button
    private lateinit var pedalBtn: Button
    private lateinit var modeBtn: Button
    private lateinit var listBox: LinearLayout
    private lateinit var body: LinearLayout

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("ap", 0)
        ui = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault)
        player = Player(this, scope)
        is88 = prefs.getBoolean("is88", false)
        player.style = Style.values()[prefs.getInt("style", 1)]
        player.pedal = prefs.getBoolean("pedal", false)
        applyKeys()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        instance = null
        player.pause(); panel?.let { wm.removeView(it) }; calView?.let { wm.removeView(it) }
        scope.cancel(); super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ---------- calibration storage ----------
    private fun calKey() = "cal${if (is88) 88 else 61}"
    private fun loadCalib(): Calib? = runCatching {
        prefs.getString(calKey(), null)?.split(",")?.map { it.toFloat() }?.let { Calib(it[0], it[1], it[2], it[3], it[4], it[5]) }
    }.getOrNull()
    private fun applyKeys() { player.keys = loadCalib()?.let { KeyMap(is88, it) } }

    // ---------- floating panel ----------
    private fun btn(t: String, f: () -> Unit) = Button(ui).apply {
        text = t; textSize = 12f; isAllCaps = false
        setPadding(dp(6), 0, dp(6), 0); minHeight = 0; minimumHeight = dp(38); minWidth = 0; minimumWidth = dp(36)
        setOnClickListener { f() }
    }
    private fun txt(t: String) = TextView(ui).apply { text = t; setTextColor(Color.WHITE); textSize = 12f }
    private fun row(vararg v: View) = LinearLayout(ui).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)) }
    }

    private fun updateLabels() {
        speedLbl.text = "Tempo ${(player.speed * 100).roundToInt()}%"
        styleBtn.text = player.style.label
        pedalBtn.text = "Pedal ${if (player.pedal) "ON" else "OFF"}"
        modeBtn.text = if (is88) "88 keys" else "61 keys"
        playBtn.text = if (player.playing) "⏸" else "▶"
    }

    fun showPanel() {
        if (panel != null) return
        val root = LinearLayout(ui).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(6), dp(6), dp(6), dp(6)); minimumWidth = dp(240)
            background = GradientDrawable().apply { setColor(0xE61E1E24.toInt()); cornerRadius = dp(12).toFloat() }
        }
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(8) }

        // header (drag handle)
        val header = txt("🎹 Auto Piano  (drag me)").apply { textSize = 13f; setPadding(dp(4), dp(6), dp(4), dp(6)) }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        header.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(root, lp) }
            }
            true
        }
        val top = LinearLayout(ui).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(header, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(btn("–") { body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE })
        top.addView(btn("✕") { player.stop(); wm.removeView(root); panel = null })
        root.addView(top)

        body = LinearLayout(ui).apply { orientation = LinearLayout.VERTICAL }
        songLbl = txt("No song picked").apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(dp(4), dp(2), dp(4), dp(4)) }
        speedLbl = txt("").apply { gravity = Gravity.CENTER }
        playBtn = btn("▶") {
            when {
                player.playing -> player.pause()
                player.keys == null -> { toast("Set up key positions first"); calibrate() }
                player.notes.isEmpty() -> toast("Pick a MIDI file first (📂)")
                else -> player.play()
            }
        }
        styleBtn = btn("") {
            val all = Style.values()
            player.style = all[(player.style.ordinal + 1) % all.size]
            prefs.edit().putInt("style", player.style.ordinal).apply(); updateLabels()
        }
        pedalBtn = btn("") {
            player.pedal = !player.pedal
            if (player.pedal && player.keys?.c?.hasPedal != true) toast("Pedal position not set — tap Calibrate and tap the pedal")
            prefs.edit().putBoolean("pedal", player.pedal).apply(); updateLabels()
        }
        modeBtn = btn("") {
            player.pause(); is88 = !is88
            prefs.edit().putBoolean("is88", is88).apply(); applyKeys(); updateLabels()
            if (player.keys == null) { toast("Set up positions for ${if (is88) 88 else 61} keys"); calibrate() }
        }
        listBox = LinearLayout(ui).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(ui).apply { visibility = View.GONE; addView(listBox) }
        listBox.tag = scroll

        body.addView(songLbl)
        body.addView(row(btn("⏮") { if (player.notes.isNotEmpty() && player.keys != null) player.restart() }, playBtn,
            btn("📂 Files") {
                if (scroll.visibility == View.VISIBLE) scroll.visibility = View.GONE
                else { scroll.visibility = View.VISIBLE; refreshList() }
            }))
        body.addView(row(btn("−5%") { player.speed = player.speed - 0.05; updateLabels() }, speedLbl,
            btn("+5%") { player.speed = player.speed + 0.05; updateLabels() }))
        body.addView(row(styleBtn, pedalBtn))
        body.addView(row(modeBtn, btn("Calibrate") { calibrate() }))
        body.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(180)))
        root.addView(body)

        player.onState = { if (panel != null) updateLabels() }
        updateLabels()
        wm.addView(root, lp); panel = root
        if (player.keys == null) { toast("First time: let's set where the keys are"); calibrate() }
    }

    // ---------- file list (from the folder you picked once) ----------
    private fun refreshList() {
        listBox.removeAllViews()
        val uri = prefs.getString("folder", null)
        if (uri == null) { listBox.addView(txt("Pick a MIDI folder in the app first")); return }
        listBox.addView(txt("Loading…"))
        scope.launch {
            val files = withContext(Dispatchers.IO) {
                DocumentFile.fromTreeUri(this@PianoService, Uri.parse(uri))?.listFiles()
                    ?.filter { val n = it.name?.lowercase() ?: ""; n.endsWith(".mid") || n.endsWith(".midi") }
                    ?.sortedBy { it.name?.lowercase() }.orEmpty()
            }
            listBox.removeAllViews()
            if (files.isEmpty()) listBox.addView(txt("No .mid files in that folder"))
            files.forEach { f -> listBox.addView(btn(f.name ?: "?") { loadSong(f) }.apply { isAllCaps = false }) }
        }
    }

    private fun loadSong(f: DocumentFile) {
        songLbl.text = "Loading…"
        scope.launch {
            try {
                val notes = withContext(Dispatchers.IO) {
                    Midi.parse(contentResolver.openInputStream(f.uri)!!.use { it.readBytes() })
                }
                player.load(notes)
                songLbl.text = "${f.name}  (${notes.size} notes)"
                (listBox.tag as View).visibility = View.GONE
            } catch (e: Exception) { songLbl.text = "Failed: ${e.message}" }
        }
    }

    // ---------- calibration: asks where the keys + pedal are ----------
    private fun calibrate() {
        if (calView != null) return
        player.pause()
        val local = ArrayList<PointF>()
        val raw = ArrayList<PointF>()
        val lo = if (is88) "A0" else "C2"; val hi = if (is88) "C8" else "C7"
        val prompts = listOf(
            "1/4  Tap the CENTER of the LOWEST (far left) white key — $lo",
            "2/4  Tap the CENTER of the HIGHEST (far right) white key — $hi",
            "3/4  Tap any BLACK key (upper part of it)",
            "4/4  Tap the PEDAL button — or press Skip if you don't use one"
        )
        val frame = FrameLayout(ui)
        frame.setBackgroundColor(0x22000000)
        val dots = object : View(ui) {
            val p = Paint().apply { color = Color.RED }
            override fun onDraw(c: Canvas) { local.forEach { c.drawCircle(it.x, it.y, dp(8).toFloat(), p) } }
        }
        frame.addView(dots, FrameLayout.LayoutParams(-1, -1))
        val prompt = TextView(ui).apply {
            text = prompts[0]; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            setBackgroundColor(0xCC000000.toInt()); setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        frame.addView(prompt, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        fun close() { wm.removeView(frame); calView = null }
        fun finish(withPedal: Boolean) {
            val px = if (withPedal) raw[3].x else -1f
            val py = if (withPedal) raw[3].y else -1f
            prefs.edit().putString(calKey(), "${raw[0].x},${raw[0].y},${raw[1].x},${raw[2].y},$px,$py").apply()
            applyKeys(); close(); toast("Saved ✅"); if (panel != null) updateLabels()
        }
        val skip = btn("Skip pedal") { if (raw.size == 3) finish(false) }.apply { visibility = View.GONE }
        val cancel = btn("Cancel") { close() }
        frame.addView(cancel, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START))
        frame.addView(skip, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END))

        frame.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                raw.add(PointF(e.rawX, e.rawY)); local.add(PointF(e.x, e.y)); dots.invalidate()
                if (raw.size == 2 && raw[1].x <= raw[0].x) {
                    toast("Second tap must be to the RIGHT of the first. Start again.")
                    raw.clear(); local.clear(); prompt.text = prompts[0]; dots.invalidate()
                } else if (raw.size == 4) finish(true)
                else { prompt.text = prompts[raw.size]; skip.visibility = if (raw.size == 3) View.VISIBLE else View.GONE }
            }
            true
        }
        val lp = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(frame, lp); calView = frame
    }
}
