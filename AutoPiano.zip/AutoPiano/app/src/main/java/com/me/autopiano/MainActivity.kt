package com.me.autopiano

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.app.Activity
import androidx.documentfile.provider.DocumentFile

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val REQ_FOLDER = 1

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        root.addView(TextView(this).apply { text = "🎹 Auto Piano"; textSize = 26f; gravity = Gravity.CENTER })
        status = TextView(this).apply { textSize = 14f; setPadding(0, pad, 0, pad) }
        root.addView(status)
        fun b(t: String, f: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        b("1. Pick your MIDI folder (one time)") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), REQ_FOLDER)
        }
        b("2. Turn on Accessibility → Auto Piano") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        b("3. Show floating piano") {
            val svc = PianoService.instance
            if (svc == null) Toast.makeText(this, "Enable the accessibility service first", Toast.LENGTH_LONG).show()
            else { svc.showPanel(); moveTaskToBack(true) }
        }
        setContentView(root)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val f = getSharedPreferences("ap", 0).getString("folder", null)
        val name = f?.let { DocumentFile.fromTreeUri(this, Uri.parse(it))?.name }
        status.text = "MIDI folder: ${name ?: "not set"}\nAccessibility service: ${if (PianoService.instance != null) "ON ✅" else "OFF ❌"}"
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (req == REQ_FOLDER && res == RESULT_OK && uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            getSharedPreferences("ap", 0).edit().putString("folder", uri.toString()).apply()
            refresh()
        }
    }
}
